//this is my footter componemt
export default function Footer(){
    return(
        <footer>
            <p>
                &copy;{new Date().getFullYear()} My Food Website ||
                Written by: Rainier Doquilo
            </p>
        </footer>
    )
}

