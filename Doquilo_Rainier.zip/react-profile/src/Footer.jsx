function Footer() {
  return (
    <footer>
      <p>
        &copy;{new Date().getFullYear()} My Profile Website ||
        Written by: Rainier V. Doquilo
      </p>
    </footer>
  );
}
export default Footer;