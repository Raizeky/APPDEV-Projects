import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './KeyApp.jsx'
import './Key.css'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
