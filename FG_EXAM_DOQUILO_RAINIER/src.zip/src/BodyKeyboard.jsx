import './Key.css';
import KeyboardDocumentation from './KeyboardDocumentation';

function Body(props){
    return(
        <div>
            <KeyboardDocumentation />
        </div> 
    )
}