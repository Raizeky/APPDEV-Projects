import Body from './BodyKeyboard';

function App() {
  return (
    <>
      <Body />
      <Header />
      <Keyboard />
    </>
  );
}