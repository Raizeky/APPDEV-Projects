export default function Header () {
    return(
        <header>
           <h1>Rain's Gaming Domain</h1>
        </header>
    )
}
