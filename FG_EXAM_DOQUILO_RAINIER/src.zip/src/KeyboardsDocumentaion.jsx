import React from 'react';

function ProductOverview() {
  return (
    <div>
      <h2>Product Overview</h2>
      <img className="KB X-1000" src="https://cf.shopee.ph/file/cb7b93af0c66ffa3bbb9c1b81d83cf59" alt="Keyboards"></img>
      <p><strong>The KB-X1000</strong> is a high-performance mechanical keyboard designed for gamers, professionals, and everyday users who demand precision and comfort. It features customizable RGB backlighting, durable mechanical switches, and programmable keys to enhance your typing and gaming experience.</p>
    </div>
  );
}

function Specifications() {
  return (
    <div>
      <h2>Specifications</h2>
      <ul>
        <li>Switch Type: Cherry MX Red (Mechanical)</li>
        <li>Key Layout: Full-size (104 keys)</li>
        <li>Backlighting: RGB with customizable colors</li>
        <li>Connectivity: Wired (USB 2.0)</li>
        <li>Dimensions: 440 mm x 135 mm x 35 mm</li>
        <li>Weight: 1.2 kg</li>
        <li>Cable Length: 1.8 meters</li>
        <li>Additional Features: Anti-ghosting, N-key rollover, dedicated media controls</li>
      </ul>
    </div>
  );
}

function InTheBox() {
  return (
    <div>
      <h2>In the Box</h2>
      <ul>
        <li>KB-X1000 Keyboard</li>
        <li>USB Cable</li>
        <li>User Manual</li>
        <li>Keycap Removal Tool</li>
        <li>Warranty Card</li>
      </ul>
    </div>
  );
}

function KeyFeatures() {
  return (
    <div>
      <h2>Key Features</h2>
      <ul>
        <li>Customizable RGB Backlighting: Personalize the keyboard’s illumination with a wide range of colors and lighting effects.</li>
        <li>Mechanical Switches: Cherry MX Red switches for a responsive and smooth typing experience.</li>
        <li>Programmable Keys: Assign macros and custom functions to any key with the included software.</li>
        <li>Anti-Ghosting & N-Key Rollover: Ensure accurate keypress registration during intense gaming sessions.</li>
        <li>Dedicated Media Controls: Easily control music and videos with dedicated media keys.</li>
      </ul>
    </div>
  );
}

function SetupInstructions() {
  return (
    <div>
      <h2>Setup Instructions</h2>
      <h3>Unboxing</h3>
      <p>Carefully remove the keyboard and accessories from the box.</p>

      <h3>Connecting the Keyboard</h3>
      <p>Plug the USB cable into an available USB port on your computer. The keyboard should be automatically recognized and ready for use. No additional drivers are required.</p>

      <h3>Software Installation (Optional)</h3>
      <p>Download the configuration software from the manufacturer’s website if you wish to customize key functions or lighting. Follow the on-screen instructions to install the software.</p>

      <h3>Keycap Removal and Replacement</h3>
      <p>Use the included keycap removal tool to gently pry off keycaps for cleaning or replacement. Replace keycaps by aligning them over the switch and pressing down until they click into place.</p>
    </div>
  );
}
function UsingTheKeyboard() {
  return (
    <div>
      <h2>Using the Keyboard</h2>
      <h3>Basic Typing</h3>
      <p>Simply start typing; the keyboard is pre-configured with standard key mappings.</p>

      <h3>Customizing Backlighting</h3>
      <p>Press Fn + F9 to cycle through preset lighting effects. Use the configuration software to create custom lighting profiles.</p>

      <h3>Programming Keys</h3>
      <p>Open the configuration software. Select the key you want to program. Assign a macro or function and save your changes.</p>

      <h3>Using Media Controls</h3>
      <p>Use the dedicated media keys (Play/Pause, Volume Up/Down, Mute) for easy media control.</p>
    </div>
  );
}

function Troubleshooting() {
  return (
    <div>
      <h2>Troubleshooting</h2>
      <h3>Keyboard Not Responding</h3>
      <p>Ensure the USB connection is secure. Try connecting the keyboard to a different USB port. Restart your computer if necessary.</p>

      <h3>Backlighting Not Working</h3>
      <p>Check if the backlight is disabled or set to a minimal brightness level. Verify that the configuration software is properly installed.</p>

      <h3>Key Not Registering</h3>
      <p>Confirm that no physical obstructions are affecting the key. Test the key in different applications to determine if the issue is software-related.</p>
    </div>
  );
}

function MaintenanceAndCare() {
  return (
    <div>
      <h2>Maintenance and Care</h2>
      <h3>Cleaning</h3>
      <p>Disconnect the keyboard from the computer. Use a soft, dry cloth to clean the surface. For deeper cleaning, carefully remove keycaps and use compressed air to remove debris.</p>

      <h3>Storage</h3>
      <p>Store the keyboard in a cool, dry place. Avoid exposure to liquids or extreme temperatures.</p>
    </div>
  );
}

function WarrantyAndSupport() {
  return (
    <div>
      <h2>Warranty and Support</h2>
      <p>Warranty Period: 2 years from the date of purchase.</p>
      <p>Customer Support: For assistance, contact customer support via the manufacturer’s website or call the support hotline at 1-800-555-1234.</p>
      <p>Manufacturer’s Website: <a href="http://www.keyboardcompany.com">www.keyboardcompany.com</a></p>
      <p>Customer Support Email: <a href="mailto:support@keyboardcompany.com">support@keyboardcompany.com</a></p>
      <p>Support Hotline: 1-800-555-1234</p>
    </div>
  );
}

function KeyboardDocumentation() {
  return (
    <div>
      <ProductOverview />
      <Specifications />
      <InTheBox />
      <KeyFeatures />
      <SetupInstructions />
      <UsingTheKeyboard />
      <Troubleshooting />
      <MaintenanceAndCare />
      <WarrantyAndSupport />
      <p>“Thank you for choosing the KB-X1000. We hope you enjoy your new keyboard! Type Safe!”</p>
    </div>
  );
}